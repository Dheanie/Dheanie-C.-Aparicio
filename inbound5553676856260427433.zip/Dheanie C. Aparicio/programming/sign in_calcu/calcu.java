/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atm_system;

/**
 *
 * @author Acer
 */
public class calcu {
    public double sum (double x, double y)
    {
      return x + y;  
    }
    public double difference (double x, double y)
    {
        return x - y;
    }
    public double product (double x, double y)
    {
        return x * y;
    }
        public double qoutient (double x, double y)
        {
            return x / y;
        }
    
    
   
  
    

}
