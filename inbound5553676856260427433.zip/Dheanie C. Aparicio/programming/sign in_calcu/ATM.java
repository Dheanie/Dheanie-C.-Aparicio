/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atm_system;

/**
 *
 * @author Acer
 */
public class ATM {
    
    private Screen screen;
    private keyboard keyboard;
    private calcu calcu;
    
   
    public ATM()
    {
         screen = new Screen ();
       keyboard = new keyboard();
       calcu = new calcu(); 
      }      
      public void run ()  
      {
    
        screen.print("Enter your Name: ");
        String name = keyboard.getString();
        int total;
        screen.print("Enter your age: ");
        int num1 = keyboard.getInt();
        screen.print("Enter your height: ");
        int num2 = keyboard.getInt();
       
        screen.print("Enter your num1: ");
       double a = keyboard.getDouble();
       
       screen.print("Enter your num2: ");
       double b = keyboard.getDouble();
       
       double sum = calcu.sum (a, b);
       screen.println ("sum: " + sum);
       double difference = calcu.difference (a, b);
       screen.println ("difference: " + difference);
       double product = calcu.product (a, b);
       screen.println ("product: " + product);
       double qoutient = calcu.qoutient (a, b);
       screen.println ("qoutient: " + qoutient);
      } 
      
       
    }


