/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atm_system;

import java.util.Scanner;

/**
 *
 * @author Acer
 */
public class keyboard {
    Scanner scan = new Scanner (System.in);
    public String getString()
          
            
    {
     return scan.nextLine();
    }
     public int getInt()
    {
     
       return scan.nextInt();
       
    }
           public double getDouble()
           {
               return scan.nextDouble();
           }
           
       }
       
    
    
    
 
    
    

