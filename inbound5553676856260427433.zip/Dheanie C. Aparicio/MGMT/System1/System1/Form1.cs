﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting; 

namespace System1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void chart4_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                fn.sql = "SELECT SUM (Sales) FROM tbl_orders";
                fn.connDB();
                fn.cmd = new SqlCommand(fn.sql, fn.conn);
                Int32 count = Convert.ToInt32(fn.cmd.ExecuteScalar());
                if (count >0)
                {
                    lbl_totalsales.Text = Convert.ToString(count.ToString("C"));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            try
            {
                fn.sql = "SELECT SUM(Profit) FROM tbl_orders";
                fn.connDB();
                fn.cmd = new SqlCommand(fn.sql, fn.conn);
                Int32 count = Convert.ToInt32(fn.cmd.ExecuteScalar());
                if (count >0)
                {
                    lbl_profit.Text = Convert.ToString(count.ToString("C"));
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
              try
            {

                fn.sql = "SELECT AVG(Sales) FROM tbl_orders WHERE OrderDate BETWEEN DATEADD(day, -7, '12/29/2017') AND '12/29/2017'";
                fn.connDB();
                fn.cmd = new SqlCommand(fn.sql, fn.conn);
                Int32 count = Convert.ToInt32(fn.cmd.ExecuteScalar());
                if (count > 0)
                {

                    lblAverageperweek.Text = Convert.ToString(count.ToString("C"));
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            try
            {
                TopSales();
                DailySales();
                SplineChart();
                BarChart();
                PieChart();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        public void TopSales()
        {
            //// TOP SALES
            fn.da = new SqlDataAdapter(fn.sql = "SELECT TOP 10 tbl_products.ProductName AS [Product Name], SUM(tbl_orders.Sales) AS [Total Sales] FROM tbl_orders INNER JOIN  tbl_products ON tbl_orders.ProductID = tbl_products.ProductID GROUP BY tbl_products.ProductName, tbl_orders.Sales ORDER BY tbl_orders.Sales DESC", fn.conn);
            fn.connDB();
            fn.dt = new DataTable();
            fn.da.Fill(fn.dt);
            dataGridView1.DataSource = fn.dt;
        }
        public void DailySales()
        {
            //// Daily Sales
            fn.sql = "SELECT SUM(Sales) FROM tbl_orders WHERE OrderDate = '12/29/2017'";
            fn.connDB();
            fn.cmd = new SqlCommand(fn.sql, fn.conn);
            Double count = Convert.ToDouble(fn.cmd.ExecuteScalar());
            if (count > 0)
            {

                lblDailySales.Text = Convert.ToString(count.ToString("C"));

            }

            fn.sql = "SELECT SUM(Sales) FROM tbl_orders WHERE OrderDate = DATEADD(day, -1, '12/29/2017')";
            fn.connDB();
            fn.cmd = new SqlCommand(fn.sql, fn.conn);
            Double percent = Convert.ToDouble(fn.cmd.ExecuteScalar());
            if (percent > 0)
            {

                double percentage = ((count - percent) / percent);

                if (count > percent)
                {
                    lblText.Text = "Increased up to";
                    lblPercent.Text = Convert.ToString(percentage.ToString("P"));
                }
                else
                {
                    lblText.Text = "Decreased down to";
                    lblPercent.Text = Convert.ToString(percentage.ToString("P"));
                }

            }

        }
        public void SplineChart()
        {

            fn.sql = "SELECT Year(ShipDate) AS Year, SUM(Profit) AS Profit, SUM(Sales) AS Sales FROM tbl_orders GROUP BY Year(ShipDate) ORDER BY 1";
            fn.connDB();
            DataSet ds = new DataSet();
            SqlDataAdapter adapt = new SqlDataAdapter(fn.sql, fn.conn);
            adapt.Fill(ds);
            chart1.DataSource = ds;

            chart1.Titles.Add("Yearly Sales");
            chart1.Series["Series1"].IsVisibleInLegend = false;
            chart1.Series["Series2"].IsVisibleInLegend = false;
            chart1.Series["Series1"].XValueMember = "Year";
            chart1.Series["Series1"].YValueMembers = "Sales";
            chart1.Series["Series2"].XValueMember = "Year";
            chart1.Series["Series2"].YValueMembers = "Profit";

        }
        public void BarChart()
        {
            fn.sql = "SELECT SUM(Sales) AS Sales, SUM(Profit) AS Profit, MONTH(OrderDate) As Monthly FROM tbl_orders WHERE YEAR(OrderDate) = YEAR('2017') GROUP BY MONTH(OrderDate) ORDER BY 1";
            fn.connDB();
            DataSet ds = new DataSet();
            SqlDataAdapter adapt = new SqlDataAdapter(fn.sql, fn.conn);
            adapt.Fill(ds);
            chart5.DataSource = ds;

            chart5.Series["Series1"].XValueMember = "Monthly";
            chart5.Series["Series1"].YValueMembers = "Sales";
            chart5.Series["Series2"].XValueMember = "Monthly";
            chart5.Series["Series2"].YValueMembers = "Profit";

            chart5.ChartAreas[0].AxisX.LabelStyle.Format = "MMM";
            chart5.ChartAreas[0].AxisX.Interval = 1;
            chart5.ChartAreas[0].AxisX.IntervalType = DateTimeIntervalType.Months;
            chart5.ChartAreas[0].AxisX.MinorTickMark.IntervalType = DateTimeIntervalType.Months;
            chart5.ChartAreas[0].AxisX.IntervalOffset = 1;
            chart5.Series["Series1"].XValueType = ChartValueType.DateTime;

            chart5.Titles.Add("Monthly Sales");


            this.chart5.Series[0].BorderColor = System.Drawing.Color.FromArgb(26, 59, 105);

            chart5.Series["Series1"].IsVisibleInLegend = false;
            chart5.Series["Series2"].IsVisibleInLegend = false;
        }
        public void PieChart()
        {

            fn.sql = "SELECT SUM(Sales) AS TOTAL, Region AS Region FROM tbl_orders GROUP BY Region";
            fn.connDB();
            DataSet ds = new DataSet();
            SqlDataAdapter adapt = new SqlDataAdapter(fn.sql, fn.conn);
            adapt.Fill(ds);
            chart4.DataSource = ds;

            chart4.Titles.Add("Sales Per Region");


            chart4.Series["Series1"].XValueMember = "Region";
            chart4.Series["Series1"].YValueMembers = "TOTAL";
            chart4.Series["Series1"].Label = "#PERCENT";
            chart4.Series["Series1"].LabelToolTip = "#VALX";
            chart4.Series["Series1"].LabelForeColor = Color.White;
            chart4.Series["Series1"].LegendText = "#VALX";
          
            this.chart4.Series[0].BorderWidth = 1;
            this.chart4.Series[0].BorderColor = System.Drawing.Color.FromArgb(26, 59, 105);
        }

       
    }
}
